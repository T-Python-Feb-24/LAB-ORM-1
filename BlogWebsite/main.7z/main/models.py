from django.db import models

# Create your models here.
class Post(models.Model):
    title = models.CharField()
    content = models.TextField()
    is_published = models.BooleanField()
    published_at =  models.DateTimeField()