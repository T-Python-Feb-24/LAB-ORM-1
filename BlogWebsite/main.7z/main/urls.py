from django.urls import path
from . import views


app_name = "main"
urlpatterns = [
    path('', views.post_view, "post_view"),
    path('', views.add_post_view, "add_post_view"),

]
