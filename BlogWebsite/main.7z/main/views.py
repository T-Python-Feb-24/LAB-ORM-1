from django.shortcuts import render
from django.http import HttpRequest, HttpResponse
from .models import Post

# Create your views here.


def post_view(request: HttpRequest):

    return render(request, "main/index.html")


def add_post_view(request: HttpRequest):

    return render(request, "main/add-post.html")
